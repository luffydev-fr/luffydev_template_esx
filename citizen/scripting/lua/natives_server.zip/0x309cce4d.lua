--- DOES_BOAT_SINK_WHEN_WRECKED
-- @param vehicle The target vehicle.
-- @return Returns whether or not the boat sinks when wrecked.
function Global.DoesBoatSinkWhenWrecked(vehicle)
	return _in(0x43f15989, vehicle, _r)
end
