--- Sets the tint index for the hair on the specified ped.
-- ```
-- NativeDB Introduced: v323
-- ```
-- @param ped The Ped whose hair tint is to be set.
-- @param colorID The tint index for the primary hair color.
-- @param highlightColorID The tint index for the hair highlight color.
function Global.SetPedHairColor(ped, colorID, highlightColorID)
	return _in(0xa23fe32c, ped, colorID, highlightColorID)
end
