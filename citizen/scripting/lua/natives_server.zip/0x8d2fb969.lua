--- STATE_BAG_HAS_KEY
-- @param bagName The name of the bag.
-- @param key The key used to check data existence.
-- @return Returns true if the data associated with the specified key exists; otherwise, returns false.
function Global.StateBagHasKey(bagName, key)
	return _in(0x12a330, _ts(bagName), _ts(key), _r)
end
