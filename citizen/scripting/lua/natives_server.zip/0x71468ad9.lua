--- IS_BOAT_ANCHORED_AND_FROZEN
-- @param vehicle The target vehicle.
-- @return Returns whether or not the boat is anchored and frozen.
function Global.IsBoatAnchoredAndFrozen(vehicle)
	return _in(0xd5c39ee6, vehicle, _r)
end
