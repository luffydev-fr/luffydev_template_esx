--- GET_THRUSTER_THROTTLE
-- @param jetpack The jetpack to check.
-- @return Returns a value representing the main throttle of the jetpack. The values range from `0.0` (no throttle) to `1.0` (full throttle)
function Global.GetThrusterThrottle(jetpack)
	return _in(0x94e24c96, jetpack, _rf)
end
