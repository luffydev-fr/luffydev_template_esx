--- GET_VEHICLE_CUSTOM_SECONDARY_COLOUR
function Global.GetVehicleCustomSecondaryColour(vehicle)
	return _in(0x3ff247a2, vehicle, _i, _i, _i)
end
