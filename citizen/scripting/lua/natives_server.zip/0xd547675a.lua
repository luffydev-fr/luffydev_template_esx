--- This will have floating point inaccuracy.
-- @param varName The console variable to get
-- @param defaultValue The default value to set, if none are found.
-- @return Returns the value set in varName, or `default` if none are specified
function Global.GetConvarFloat(varName, defaultValue)
	return _in(0x9e666d, _ts(varName), defaultValue, _rf)
end
