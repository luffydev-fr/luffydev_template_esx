--- CLEAR_PED_SECONDARY_TASK
function Global.ClearPedSecondaryTask(ped)
	return _in(0xa635f451, ped)
end
