--- IS_PED_RAGDOLL
-- @param ped The target ped.
-- @return Whether or not the ped is ragdolling.
function Global.IsPedRagdoll(ped)
	return _in(0xc833bbe1, ped, _r)
end
