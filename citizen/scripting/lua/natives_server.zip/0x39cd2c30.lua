--- Deletes the specified `entity` and any carriage its attached to, or that is attached to it.
-- @param entity The carriage to delete.
function Global.DeleteTrain(entity)
	return _in(0x523ba3da, entity)
end
