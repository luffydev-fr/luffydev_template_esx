--- IS_BOAT_WRECKED
-- @param vehicle The target vehicle.
-- @return Returns whether or not the boat is wrecked.
function Global.IsBoatWrecked(vehicle)
	return _in(0x9049db44, vehicle, _r)
end
