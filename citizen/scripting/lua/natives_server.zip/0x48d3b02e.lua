--- GET_HELI_ROLL_CONTROL
-- @param heli The helicopter to check.
-- @return Returns a value representing the roll control of the helicopter. The values range from `-1.0` (roll left) to `1.0` (roll right), with `0.0` indicating no roll input.
function Global.GetHeliRollControl(heli)
	return _in(0x12948de9, heli, _rf)
end
