--- TASK_GO_STRAIGHT_TO_COORD
-- @param ped The ped handle.
-- @param x The x coordinate.
-- @param y The y coordinate.
-- @param z The z coordinate.
-- @param speed The ped movement speed.
-- @param timeout \-1 , other values appear to break the ped movement.
-- @param targetHeading The heading you want the ped to be on x,y,z coord.
-- @param distanceToSlide The distance from x,y,z where the ped will start sliding.
function Global.TaskGoStraightToCoord(ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)
	return _in(0x80a9e7a7, ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)
end
