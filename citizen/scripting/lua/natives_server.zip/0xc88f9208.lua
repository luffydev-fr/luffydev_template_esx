--- GET_PED_DESIRED_HEADING
-- @param ped The target ped
-- @return Returns ped's desired heading.
function Global.GetPedDesiredHeading(ped)
	return _in(0xc182f76e, ped, _rf)
end
