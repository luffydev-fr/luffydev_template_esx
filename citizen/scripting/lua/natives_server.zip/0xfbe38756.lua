--- See the client-side [IS_VEHICLE_WINDOW_INTACT](#\_0x46E571A0E20D01F1) for a window indexes list.
-- @param vehicle The target vehicle.
-- @param windowIndex The window index.
function Global.IsVehicleWindowIntact(vehicle, windowIndex)
	return _in(0xac4ef23d, vehicle, windowIndex, _r)
end
