--- IS_PED_HANDCUFFED
-- @param ped The target ped.
-- @return Whether or not the ped is handcuffed.
function Global.IsPedHandcuffed(ped)
	return _in(0x25865633, ped, _r)
end
