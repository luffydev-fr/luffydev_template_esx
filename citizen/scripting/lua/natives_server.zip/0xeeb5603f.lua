--- DOES_TRAIN_STOP_AT_STATIONS
-- @param train The train handle
-- @return True if the train stops at stations. False otherwise
function Global.DoesTrainStopAtStations(train)
	return _in(0x77cc80dc, train, _r)
end
