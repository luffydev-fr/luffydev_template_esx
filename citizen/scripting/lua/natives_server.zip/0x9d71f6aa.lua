--- SET_PED_RANDOM_PROPS
-- @param ped The ped handle.
function Global.SetPedRandomProps(ped)
	return _in(0xe3318e0e, ped)
end
