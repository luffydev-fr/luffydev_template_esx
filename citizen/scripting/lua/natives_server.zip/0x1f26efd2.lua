--- GET_VEHICLE_STEERING_ANGLE
function Global.GetVehicleSteeringAngle(vehicle)
	return _in(0x1382fcea, vehicle, _rf)
end
