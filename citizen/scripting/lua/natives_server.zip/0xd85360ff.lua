--- IS_PRINCIPAL_ACE_ALLOWED
function Global.IsPrincipalAceAllowed(principal, object)
	return _in(0x37cf52ce, _ts(principal), _ts(object), _r)
end
