--- Can be used to get a console variable casted back to `bool`.
-- @param varName The console variable to look up.
-- @param defaultValue The default value to set if none is found.
-- @return Returns the convar value if it can be found, otherwise it returns the assigned `default`.
function Global.GetConvarBool(varName, defaultValue)
	return _in(0x7e8ebfe5, _ts(varName), defaultValue, _r)
end
