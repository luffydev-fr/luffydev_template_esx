--- GET_PLAYER_FROM_INDEX
function Global.GetPlayerFromIndex(index)
	return _in(0xc8a9ce08, index, _s)
end
