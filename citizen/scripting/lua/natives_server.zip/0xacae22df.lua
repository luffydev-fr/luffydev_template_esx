--- Returns all commands registered by the specified resource.
-- The data returned adheres to the following layout:
-- ```
-- [
-- {
-- "name": "cmdlist",
-- "resource": "example_resource",
-- "arity" = -1,
-- },
-- {
-- "name": "command1"
-- "resource": "example_resource2",
-- "arity" = -1,
-- }
-- ]
-- ```
-- @return An object containing registered commands.
function Global.GetResourceCommands(resource)
	return _in(0x97628584, _ts(resource), _ro)
end
