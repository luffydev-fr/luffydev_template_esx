--- NETWORK_GET_VOICE_PROXIMITY_OVERRIDE_FOR_PLAYER
-- @param playerSrc The player handle
function Global.NetworkGetVoiceProximityOverrideForPlayer(playerSrc)
	return _in(0xffeef513, _ts(playerSrc), _rv)
end
