--- GET_PED_IN_VEHICLE_SEAT
-- @param vehicle The target vehicle.
-- @param seatIndex See eSeatPosition declared in [`IS_VEHICLE_SEAT_FREE`](#\_0x22AC59A870E6A669).
-- @return The ped in the specified seat of the passed vehicle. Returns 0 if the specified seat is not occupied.
function Global.GetPedInVehicleSeat(vehicle, seatIndex)
	return _in(0x388fde9a, vehicle, seatIndex, _ri)
end
