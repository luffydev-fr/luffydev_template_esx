--- An internal function for converting a stack trace object to a string.
function Global.FormatStackTrace(traceData)
	local traceData_bytes, traceData_len = _obj(traceData)
	return _in(0xd70c3bca, traceData_bytes, traceData_len, _s)
end
