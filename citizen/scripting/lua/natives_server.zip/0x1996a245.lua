--- GET_VEHICLE_WHEEL_TYPE
function Global.GetVehicleWheelType(vehicle)
	return _in(0xda58d7ae, vehicle, _ri)
end
