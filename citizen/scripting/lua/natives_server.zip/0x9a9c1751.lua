--- GET_TRAIN_STATE
-- @param train The train handle
-- @return The trains current state```cpp
-- 		enum eTrainState
-- 		{
-- 		    MOVING = 0,
-- 		    ENTERING_STATION,
-- 		    OPENING_DOORS,
-- 		    STOPPED,
-- 		    CLOSING_DOORS,
-- 		    LEAVING_STATION,
-- 		}
-- 		```
function Global.GetTrainState(train)
	return _in(0x81b50033, train, _ri)
end
