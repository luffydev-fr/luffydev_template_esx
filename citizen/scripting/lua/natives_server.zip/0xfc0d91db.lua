--- See [GET_PLAYER_PEER_STATISTICS](#\_0x9A928294) if you want more detailed information, like packet loss, and packet/rtt variance
-- @return Returns the mean amount of time a packet takes to get to the client
function Global.GetPlayerPing(playerSrc)
	return _in(0xff1290d4, _ts(playerSrc), _ri)
end
