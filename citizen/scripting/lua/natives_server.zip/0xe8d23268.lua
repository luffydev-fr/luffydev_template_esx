--- GET_HELI_PITCH_CONTROL
-- @param heli The helicopter to check.
-- @return Returns a value representing the pitch control of the helicopter. The values range from `-1.0` (nose down) to `1.0` (nose up), with `0.0` indicating no pitch input.
function Global.GetHeliPitchControl(heli)
	return _in(0x1944ac95, heli, _rf)
end
